import torch
import torch.nn as nn
import torch.nn.functional as F
from einops import rearrange, repeat
from fla.modules import RMSNorm, ShortConvolution
from fla.modules.l2norm import l2norm
from typing import TYPE_CHECKING, Dict, Optional, Tuple, List

try:
    from src.models.spike.neuron import registry as neuron_registry
    from src.models.spike.surrogate import piecewise_quadratic_surrogate
except (ImportError, ModuleNotFoundError):
    class DummySurrogate(torch.autograd.Function):
        @staticmethod
        def forward(ctx, input): return input
        @staticmethod
        def backward(ctx, grad_output): return grad_output
    neuron_registry = {'sdn': lambda surrogate_function: DummySurrogate.apply}
    piecewise_quadratic_surrogate = lambda: None

class SpikingLinear(nn.Module):
    def __init__(self, linear_layer: nn.Linear, neuron_type: str, surrogate_function):
        super().__init__()
        self.neuron = neuron_registry[neuron_type](surrogate_function=surrogate_function)
        self.linear = linear_layer

    def forward(self, x):
        x_transposed = x.transpose(-1, -2)
        spikes = self.neuron(x_transposed).transpose(-1, -2)
        return self.linear(spikes), spikes

# ==================== White-box Operator (Mamba2 SSD) ====================

def mamba2_ssd_parallel_stable(q, k, v, a, chunk_size=64, initial_state=None):
    b, h, l, d = q.shape
    
    pad_len = (chunk_size - l % chunk_size) % chunk_size
    if pad_len > 0:
        q, k, v = [F.pad(x, (0, 0, 0, pad_len)) for x in [q, k, v]]
        a = F.pad(a, (0, pad_len), value=0.0)
    
    q, k, v = [rearrange(x, 'b h (n c) d -> b h n c d', c=chunk_size) for x in [q, k, v]]
    a_chunk = rearrange(a, 'b h (n c) -> b h n c', c=chunk_size)
    
    num_chunks = q.shape[2]
    S = initial_state if initial_state is not None else torch.zeros(b, h, d, d, device=q.device)
    o = torch.zeros_like(v)
    
    mask_tril = torch.tril(torch.ones(chunk_size, chunk_size, device=q.device, dtype=torch.bool), diagonal=-1)

    for i in range(num_chunks):
        q_i, k_i, v_i, a_i = q[:, :, i], k[:, :, i], v[:, :, i], a_chunk[:, :, i]
        
        a_i_cumsum = torch.cumsum(a_i, dim=-1)
        rel_cumsum = a_i_cumsum.unsqueeze(-1) - a_i_cumsum.unsqueeze(-2)
        
        decay_rel = torch.exp(rel_cumsum.clamp(max=0.0)) * mask_tril
        
        attn_intra = (q_i @ k_i.transpose(-1, -2)) * decay_rel
        o_intra = attn_intra @ v_i
        
        decay_from_start = torch.exp(a_i_cumsum).unsqueeze(-1)
        o_inter = (q_i * (decay_from_start + 1e-8)) @ S
        
        o[:, :, i] = o_inter + o_intra
        
        decay_total = torch.exp(a_i.sum(dim=-1, keepdim=True)).unsqueeze(-1)
        decay_to_end = torch.exp(a_i_cumsum[..., -1].unsqueeze(-1) - a_i_cumsum).unsqueeze(-1)
        
        delta_S = (k_i * decay_to_end).transpose(-1, -2) @ v_i
        S = S * (decay_total + 1e-8) + delta_S
        
        S = torch.clamp(S, -10.0, 10.0)

    o = rearrange(o, 'b h n c d -> b h (n c) d')
    return (o[:, :, :l, :], S) if pad_len > 0 else (o, S)

# ==================== White-box Operator (GSA) ====================

def gsa_chunkwise(q, k, v, f, chunk_size=64, initial_state=None):
    b, h, l, d = v.shape
    num_slots = q.shape[-1]
    
    pad_len = (chunk_size - l % chunk_size) % chunk_size
    if pad_len > 0:
        q, k, v, f = [F.pad(x, (0, 0, 0, pad_len)) for x in [q, k, v, f]]
        
    q = rearrange(q, 'b h (n c) m -> b h n c m', c=chunk_size)
    k = rearrange(k, 'b h (n c) m -> b h n c m', c=chunk_size)
    v = rearrange(v, 'b h (n c) d -> b h n c d', c=chunk_size)
    f = rearrange(f, 'b h (n c) m -> b h n c m', c=chunk_size)
    
    k = torch.softmax(k, dim=-1)
    q = torch.softmax(q, dim=-1)
    
    f = F.logsigmoid(f)
    
    if initial_state is not None:
        S = initial_state
    else:
        S = torch.zeros(b, h, num_slots, d, device=q.device)
        
    o_list = []
    
    for i in range(q.shape[2]):
        q_chunk = q[:, :, i]
        k_chunk = k[:, :, i]
        v_chunk = v[:, :, i]
        f_chunk = f[:, :, i]
        
        f_cumsum = torch.cumsum(f_chunk, dim=-2)
        
        decay_exp = torch.exp(f_cumsum)
        decay_inv_exp = torch.exp(-f_cumsum)
        
        q_mod = q_chunk * decay_exp
        k_mod = k_chunk * decay_inv_exp
        
        attn_score = q_mod @ k_mod.transpose(-1, -2)
        
        mask = torch.triu(torch.ones(chunk_size, chunk_size, dtype=torch.bool, device=q.device), diagonal=1)
        attn_score = attn_score.masked_fill(mask, 0)
        
        o_intra = attn_score @ v_chunk
        
        q_decayed = q_chunk * decay_exp
        
        o_inter = q_decayed @ S
        
        o_list.append(o_intra + o_inter)
        
        c_end_per_slot = f_cumsum[:, :, -1, :].unsqueeze(-2)
        decay_to_end_const_per_slot = torch.exp(c_end_per_slot)
        
        k_weighted_for_state_update = k_mod * decay_to_end_const_per_slot
        
        chunk_update = k_weighted_for_state_update.transpose(-1, -2) @ v_chunk
        
        current_chunk_total_decay_factor = torch.exp(f_chunk.sum(dim=-2)).unsqueeze(-1)

        S = S * current_chunk_total_decay_factor + chunk_update
        
    o = torch.stack(o_list, dim=2)
    o = rearrange(o, 'b h n c d -> b h (n c) d')
    if pad_len > 0: o = o[..., :l, :]
    return o, S

# ==================== SpikingMamba2 Layer ====================

class SpikingMamba2(nn.Module):
    def __init__(self, d_model: int=1024, num_heads: int=8, expand: int=2, d_state: int=64, neuron_type: str='sdn', layer_idx: int=None, **kwargs):
        super().__init__()
        self.layer_idx = layer_idx
        self.d_inner = int(expand * d_model)
        self.num_heads = num_heads 
        self.d_head = self.d_inner // num_heads

        self.proj_out_dim = self.d_inner * 4 + num_heads
        surrogate = piecewise_quadratic_surrogate()

        self.in_proj = SpikingLinear(nn.Linear(d_model, self.proj_out_dim, bias=False), neuron_type, surrogate)
        self.conv1d = ShortConvolution(self.d_inner, kernel_size=4, activation='silu')

        self.decay_proj = SpikingLinear(nn.Linear(d_model, num_heads, bias=False), neuron_type, surrogate)
        self.decay_bias = nn.Parameter(torch.zeros(num_heads))

        self.D = nn.Parameter(torch.ones(num_heads))

        self.norm = RMSNorm(self.d_inner)
        self.out_proj = SpikingLinear(nn.Linear(self.d_inner, d_model, bias=False), neuron_type, surrogate)

    def forward(self, x, past_key_values=None, **kwargs):
        all_spikes = {}
        projected, s_in = self.in_proj(x)
        all_spikes['in_proj'] = s_in

        z, x_in, B, C, _ = torch.split(projected, [self.d_inner, self.d_inner, self.d_inner, self.d_inner, self.num_heads], dim=-1)

        conv_state = None
        if past_key_values is not None and self.layer_idx in past_key_values:
             conv_state = past_key_values[self.layer_idx].get('conv_state')
        x_in, new_conv_state = self.conv1d(x_in, cache=conv_state, output_final_state=True)

        v = rearrange(x_in, 'b l (h d) -> b h l d', h=self.num_heads)
        k = rearrange(B, 'b l (h d) -> b h l d', h=self.num_heads)
        q = rearrange(C, 'b l (h d) -> b h l d', h=self.num_heads)

        decay_raw, s_decay = self.decay_proj(x)
        all_spikes['decay_proj'] = s_decay
        a = -F.softplus(decay_raw + self.decay_bias)
        a = rearrange(a, 'b l h -> b h l')

        last_state = None
        if past_key_values is not None and self.layer_idx in past_key_values:
            last_state = past_key_values[self.layer_idx].get('recurrent_state')

        y, final_state = mamba2_ssd_parallel_stable(q, k, v, a, initial_state=last_state)

        if past_key_values is not None:
            past_key_values[self.layer_idx] = {'recurrent_state': final_state, 'conv_state': new_conv_state}

        y = y + (self.D.view(1, -1, 1, 1) * v)
        y = rearrange(y, 'b h l d -> b l (h d)')
        y = self.norm(y)
        y = y * F.silu(z) 

        y, s_out = self.out_proj(y)
        all_spikes['out_proj'] = s_out

        return y, None, all_spikes

# ==================== GSA Layer ====================

class GSA(nn.Module):
    def __init__(self, d_model, num_heads, num_slots=64, expand_v=1.0, use_short_conv=True, conv_size=4, neuron_type='sdn', **kwargs):
        super().__init__()
        self.d_model = d_model
        self.num_heads = num_heads
        self.num_slots = num_slots
        self.value_dim = int(d_model * expand_v)
        surrogate = piecewise_quadratic_surrogate()

        self.q_proj = SpikingLinear(nn.Linear(d_model, num_heads * num_slots, bias=False), neuron_type, surrogate)
        self.k_proj = SpikingLinear(nn.Linear(d_model, num_heads * num_slots, bias=False), neuron_type, surrogate)
        self.v_proj = SpikingLinear(nn.Linear(d_model, self.value_dim, bias=False), neuron_type, surrogate)
        self.f_proj = SpikingLinear(nn.Linear(d_model, num_heads * num_slots, bias=False), neuron_type, surrogate) 
        self.g_proj = SpikingLinear(nn.Linear(d_model, self.value_dim, bias=False), neuron_type, surrogate) 

        self.o_proj = SpikingLinear(nn.Linear(self.value_dim, d_model, bias=False), neuron_type, surrogate)
        self.g_norm = RMSNorm(self.value_dim // num_heads)

        self.use_short_conv = use_short_conv
        if use_short_conv:
            self.q_conv1d = ShortConvolution(num_heads * num_slots, conv_size, activation='silu')
            self.k_conv1d = ShortConvolution(num_heads * num_slots, conv_size, activation='silu')
            self.v_conv1d = ShortConvolution(self.value_dim, conv_size, activation='silu')
            self.f_conv1d = ShortConvolution(num_heads * num_slots, conv_size, activation='silu')

    def forward(self, x, past_key_values=None, layer_idx=None, **kwargs):
        all_spikes = {}

        q, s_q = self.q_proj(x)
        k, s_k = self.k_proj(x)
        v, s_v = self.v_proj(x)
        f, s_f = self.f_proj(x)
        g, s_g = self.g_proj(x)
        all_spikes.update({'q': s_q, 'k': s_k, 'v': s_v, 'f': s_f, 'g': s_g})

        if self.use_short_conv:
            q, _ = self.q_conv1d(q)
            k, _ = self.k_conv1d(k)
            v, _ = self.v_conv1d(v)
            f, _ = self.f_conv1d(f)

        q = rearrange(q, 'b l (h m) -> b h l m', h=self.num_heads, m=self.num_slots)
        k = rearrange(k, 'b l (h m) -> b h l m', h=self.num_heads, m=self.num_slots)
        v = rearrange(v, 'b l (h d) -> b h l d', h=self.num_heads)
        f = rearrange(f, 'b l (h m) -> b h l m', h=self.num_heads, m=self.num_slots)

        last_state = None
        if past_key_values is not None and layer_idx is not None:
             if len(past_key_values) > layer_idx:
                 last_state = past_key_values[layer_idx].get('recurrent_state')

        o, final_state = gsa_chunkwise(q, k, v, f, chunk_size=64, initial_state=last_state)

        if past_key_values is not None and layer_idx is not None:
            if len(past_key_values) <= layer_idx:
                past_key_values.append({'recurrent_state': final_state})
            else:
                past_key_values[layer_idx]['recurrent_state'] = final_state

        o = rearrange(o, 'b h l d -> b l h d')
        o = self.g_norm(o)

        g = rearrange(g, 'b l (h d) -> b l h d', h=self.num_heads)
        o = o * F.silu(g)

        o = rearrange(o, 'b l h d -> b l (h d)')
        o, s_o = self.o_proj(o)
        all_spikes['o'] = s_o
        return o, None, all_spikes

# ==================== SpikingMLP ====================

class SpikingMLP(nn.Module):
    def __init__(self, d_model, d_ffn, dropout=0.1, neuron_type='sdn', surrogate_function=None):
        super().__init__()
        self.fc1 = SpikingLinear(nn.Linear(d_model, d_ffn), neuron_type, surrogate_function)
        self.dropout = nn.Dropout(dropout)
        self.fc2 = SpikingLinear(nn.Linear(d_ffn, d_model), neuron_type, surrogate_function)

    def forward(self, x):
        x, spike1 = self.fc1(x)
        x, spike2 = self.fc2(self.dropout(x))
        return x, spike1, spike2

# ==================== Main SpikingFLABlock ====================

class SpikingFLABlock(nn.Module):
    def __init__(self, d_model, num_heads, d_ffn_mult=2, dropout=0.1, prenorm=True, neuron_type='sdn', num_slots=64, **kwargs):
        super().__init__()
        self.prenorm = prenorm
        self.norm1 = RMSNorm(d_model)
        self.mamba2 = SpikingMamba2(d_model=d_model, num_heads=num_heads, neuron_type=neuron_type, **kwargs)
        self.gsa = GSA(d_model=d_model, num_heads=num_heads, num_slots=num_slots, neuron_type=neuron_type, **kwargs)
        self.dropout1 = nn.Dropout(dropout)

        self.norm2 = RMSNorm(d_model)
        d_ffn = d_model * d_ffn_mult

        self.mlp = SpikingMLP(d_model=d_model, d_ffn=d_ffn, dropout=dropout, neuron_type=neuron_type, surrogate_function=piecewise_quadratic_surrogate())
        self.dropout2 = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor, **kwargs) -> Tuple[torch.Tensor, Optional[torch.Tensor], Optional[torch.Tensor]]:
        all_spikes_list = []

        # --- Combined Attention Block (Mamba2 + GSA) ---
        x_res = x
        if self.prenorm: x = self.norm1(x)

        x_mamba2, _, mamba2_spikes = self.mamba2(x, **kwargs)
        x_gsa, _, gsa_spikes = self.gsa(x, **kwargs)

        # Combine outputs with fixed scaling
        x_attn = (x_mamba2 + x_gsa) * 0.5

        if mamba2_spikes:
            for spike_tensor in mamba2_spikes.values():
                if spike_tensor is not None:
                    all_spikes_list.append(spike_tensor)
        if gsa_spikes:
            for spike_tensor in gsa_spikes.values():
                if spike_tensor is not None:
                    all_spikes_list.append(spike_tensor)

        x = x_res + self.dropout1(x_attn)

        # --- MLP Block ---
        x_res = x
        if self.prenorm: x = self.norm2(x)

        x_mlp, mlp_spike1, mlp_spike2 = self.mlp(x)

        if mlp_spike1 is not None:
            all_spikes_list.append(mlp_spike1)
        if mlp_spike2 is not None:
            all_spikes_list.append(mlp_spike2)

        x_mlp = x_mlp * 0.5  # Fixed scaling instead of learned gate
        x = x_res + self.dropout2(x_mlp)

        final_spikes = torch.cat([s.flatten() for s in all_spikes_list]) if all_spikes_list else torch.empty(0, device=x.device, dtype=torch.bool)

        return x, None, final_spikes