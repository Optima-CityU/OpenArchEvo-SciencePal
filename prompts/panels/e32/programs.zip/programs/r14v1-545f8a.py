import torch
import torch.nn as nn
import torch.nn.functional as F
from einops import rearrange, repeat
from fla.modules import RMSNorm, ShortConvolution
from fla.modules.l2norm import l2norm

try:
    from src.models.spike.neuron import registry as neuron_registry
    from src.models.spike.surrogate import piecewise_quadratic_surrogate
except (ImportError, ModuleNotFoundError):
    class DummySurrogate(torch.autograd.Function):
        @staticmethod
        def forward(ctx, input): return input
        @staticmethod
        def backward(ctx, grad_output): return grad_output
    neuron_registry = {'sdn': lambda surrogate_function: DummySurrogate.apply}
    piecewise_quadratic_surrogate = lambda: None

class SpikingLinear(nn.Module):
    def __init__(self, linear_layer: nn.Linear, neuron_type: str, surrogate_function):
        super().__init__()
        self.neuron = neuron_registry[neuron_type](surrogate_function=surrogate_function)
        self.linear = linear_layer

    def forward(self, x):
        x_transposed = x.transpose(-1, -2)
        spikes = self.neuron(x_transposed).transpose(-1, -2)
        return self.linear(spikes), spikes

# ==================== Diagonal State SSD Operator ====================

def mamba2_ssd_diagonal_parallel_stable(q, k, v, a, chunk_size=64, initial_state=None):
    b, h, l, d = q.shape
    
    pad_len = (chunk_size - l % chunk_size) % chunk_size
    if pad_len > 0:
        q, k, v = [F.pad(x, (0, 0, 0, pad_len)) for x in [q, k, v]]
        a = F.pad(a, (0, pad_len), value=0.0)
    
    q, k, v = [rearrange(x, 'b h (n c) d -> b h n c d', c=chunk_size) for x in [q, k, v]]
    a_chunk = rearrange(a, 'b h (n c) -> b h n c', c=chunk_size)
    
    num_chunks = q.shape[2]
    S = initial_state if initial_state is not None else torch.zeros(b, h, device=q.device)
    o = torch.zeros_like(v)
    
    mask_tril = torch.tril(torch.ones(chunk_size, chunk_size, device=q.device, dtype=torch.bool), diagonal=-1)

    for i in range(num_chunks):
        q_i, k_i, v_i, a_i = q[:, :, i], k[:, :, i], v[:, :, i], a_chunk[:, :, i]
        
        a_i_cumsum = torch.cumsum(a_i, dim=-1)
        rel_cumsum = a_i_cumsum.unsqueeze(-1) - a_i_cumsum.unsqueeze(-2)
        
        decay_rel = torch.exp(rel_cumsum.clamp(max=0.0)) * mask_tril
        
        attn_intra = torch.zeros_like(q_i)
        for c in range(chunk_size):
            attn_intra[:, :, c] = q_i[:, :, c] * torch.sum(
                decay_rel[:, :, c, :c+1].unsqueeze(-1) * k_i[:, :, :c+1] * v_i[:, :, :c+1], 
                dim=-2
            )
        
        decay_from_start = torch.exp(a_i_cumsum).unsqueeze(-1)
        o_inter = q_i * (decay_from_start * S.unsqueeze(-1).unsqueeze(-1))
        
        o[:, :, i] = o_inter + attn_intra
        
        decay_total = torch.exp(a_i.sum(dim=-1, keepdim=True))
        decay_to_end = torch.exp(a_i_cumsum[..., -1].unsqueeze(-1) - a_i_cumsum)
        
        delta_S = torch.einsum('bhc,bhcd->bh', decay_to_end, k_i * v_i)
        
        S = S * (decay_total.squeeze(-1) + 1e-8) + delta_S
        
        S = torch.clamp(S, -10.0, 10.0)

    o = rearrange(o, 'b h n c d -> b h (n c) d')
    return (o[:, :, :l, :], S) if pad_len > 0 else (o, S)

# ==================== SpikingMamba2Diagonal-DualValue-Gated Layer ====================

class SpikingMamba2DiagonalDualValueGated(nn.Module):
    def __init__(self, d_model: int=1024, num_heads: int=8, expand: int=2, d_state: int=64, neuron_type: str='sdn', layer_idx: int=None, **kwargs):
        super().__init__()
        self.layer_idx = layer_idx
        self.d_inner = int(expand * d_model)
        self.num_heads = num_heads 
        self.d_head = self.d_inner // num_heads

        # proj_out_dim = d_inner (z) + d_inner (x) + d_inner (B) + num_heads (dt)
        self.proj_out_dim = self.d_inner * 3 + num_heads
        surrogate = piecewise_quadratic_surrogate()

        self.in_proj = SpikingLinear(nn.Linear(d_model, self.proj_out_dim, bias=False), neuron_type, surrogate)
        self.conv1d = ShortConvolution(self.d_inner, kernel_size=4, activation='silu')

        # Dual value pathway
        self.v_proj_cont = SpikingLinear(nn.Linear(d_model, self.d_inner, bias=False), neuron_type, surrogate)
        self.v_conv1d_cont = ShortConvolution(self.d_inner, kernel_size=4, activation='silu')

        # Learned gate for continuous value pathway
        self.gate_proj = SpikingLinear(nn.Linear(d_model, num_heads, bias=False), neuron_type, surrogate)

        self.dt_bias = nn.Parameter(torch.ones(num_heads) * -2.0)
        self.D = nn.Parameter(torch.ones(num_heads))

        self.norm = RMSNorm(self.d_inner)
        self.out_proj = SpikingLinear(nn.Linear(self.d_inner, d_model, bias=False), neuron_type, surrogate)

    def forward(self, x, past_key_values=None, **kwargs):
        all_spikes = {}
        projected, s_in = self.in_proj(x)
        all_spikes['in_proj'] = s_in

        z, x_in, B, dt = torch.split(projected, [self.d_inner, self.d_inner, self.d_inner, self.num_heads], dim=-1)

        conv_state = None
        if past_key_values is not None and self.layer_idx in past_key_values:
             conv_state = past_key_values[self.layer_idx].get('conv_state')
        x_in, new_conv_state = self.conv1d(x_in, cache=conv_state, output_final_state=True)

        # Dual value pathway: continuous branch
        v_cont, s_v_cont = self.v_proj_cont(x)
        all_spikes['v_proj_cont'] = s_v_cont
        v_cont, _ = self.v_conv1d_cont(x=v_cont, cache=None, output_final_state=False, cu_seqlens=None)

        # Compute gate for continuous value pathway
        gate, s_gate = self.gate_proj(x)
        all_spikes['gate_proj'] = s_gate
        gate = torch.sigmoid(gate.unsqueeze(-1))  # (B, L, num_heads, 1)
        gate = gate.transpose(1, 2)  # (B, num_heads, L, 1)

        v = rearrange(x_in, 'b l (h d) -> b h l d', h=self.num_heads)
        k = rearrange(B, 'b l (h d) -> b h l d', h=self.num_heads)
        q_scalar = k.mean(dim=-1, keepdim=True)
        q = q_scalar.expand(-1, -1, -1, self.d_head)

        a = -F.softplus(dt + self.dt_bias)
        a = rearrange(a, 'b l h -> b h l')

        last_state = None
        if past_key_values is not None and self.layer_idx in past_key_values:
            last_state = past_key_values[self.layer_idx].get('recurrent_state')

        y, final_state = mamba2_ssd_diagonal_parallel_stable(q, k, v, a, initial_state=last_state)

        # Add the gated continuous value stream to the spiking value
        v_cont = rearrange(v_cont, 'b l (h d) -> b h l d', h=self.num_heads)
        y = y + gate * v_cont

        if past_key_values is not None:
            past_key_values[self.layer_idx] = {'recurrent_state': final_state, 'conv_state': new_conv_state}

        y = y + (self.D.view(1, -1, 1, 1) * v)
        y = rearrange(y, 'b h l d -> b l (h d)')
        y = self.norm(y)
        y = y * F.silu(z) 

        y, s_out = self.out_proj(y)
        all_spikes['out_proj'] = s_out

        return y, None, all_spikes

class SpikingMLP(nn.Module):
    def __init__(self, d_model, d_ffn, dropout=0.1, neuron_type='sdn', surrogate_function=None):
        super().__init__()
        self.fc1 = SpikingLinear(nn.Linear(d_model, d_ffn), neuron_type, surrogate_function)
        self.dropout = nn.Dropout(dropout)
        self.fc2 = SpikingLinear(nn.Linear(d_ffn, d_model), neuron_type, surrogate_function)

    def forward(self, x):
        x, spike1 = self.fc1(x)
        x = F.gelu(x) 
        x, spike2 = self.fc2(self.dropout(x))
        return x, spike1, spike2

class SpikingFLABlock(nn.Module):
    def __init__(self, d_model, num_heads, d_ffn_mult=2, dropout=0.1, prenorm=True, neuron_type='sdn', **kwargs):
        super().__init__()
        self.prenorm = prenorm
        self.norm1 = RMSNorm(d_model)
        self.attn = SpikingMamba2DiagonalDualValueGated(d_model=d_model, num_heads=num_heads, neuron_type=neuron_type, **kwargs)
        self.dropout1 = nn.Dropout(dropout)
        self.norm2 = RMSNorm(d_model)
        d_ffn = d_model * d_ffn_mult
        self.mlp = SpikingMLP(d_model=d_model, d_ffn=d_ffn, dropout=dropout, neuron_type=neuron_type, surrogate_function=piecewise_quadratic_surrogate())
        self.dropout2 = nn.Dropout(dropout)

    def forward(self, x, **kwargs):
        all_spikes_list = []
        x_res = x
        if self.prenorm: x = self.norm1(x)
        x_attn, _, attn_spikes = self.attn(x, **kwargs)
        if attn_spikes: all_spikes_list.extend(attn_spikes.values())
        x = x_res + self.dropout1(x_attn)
        x_res = x
        if self.prenorm: x = self.norm2(x)
        x_mlp, s1, s2 = self.mlp(x)
        all_spikes_list.extend([s1, s2])
        x = x + x_mlp
        final_spikes = torch.cat([s.flatten() for s in all_spikes_list]) if all_spikes_list else None
        return x, None, final_spikes
