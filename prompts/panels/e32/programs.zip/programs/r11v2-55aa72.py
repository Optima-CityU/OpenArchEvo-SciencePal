import torch
import torch.nn as nn
import torch.nn.functional as F
from einops import rearrange
from fla.modules import RMSNorm, ShortConvolution
from typing import Tuple, List, Optional

try:
    from src.models.spike.neuron import registry as neuron_registry
    from src.models.spike.surrogate import piecewise_quadratic_surrogate
except (ImportError, ModuleNotFoundError):
    class DummySurrogate(torch.autograd.Function):
        @staticmethod
        def forward(ctx, input): return input
        @staticmethod
        def backward(ctx, grad_output): return grad_output
    neuron_registry = {'sdn': lambda surrogate_function: DummySurrogate.apply}
    piecewise_quadratic_surrogate = lambda: None

class SpikingLinear(nn.Module):
    def __init__(self, linear_layer: nn.Linear, neuron_type: str, surrogate_function):
        super().__init__()
        self.neuron = neuron_registry[neuron_type](surrogate_function=surrogate_function)
        self.linear = linear_layer

    def forward(self, x):
        x_transposed = x.transpose(-1, -2)
        spikes = self.neuron(x_transposed).transpose(-1, -2)
        return self.linear(spikes), spikes

# ==================== HGRN2 Operator (from i00-hgrn2) ====================

def hgrn2_chunkwise(g, x, chunk_size=64, initial_state=None):
    """HGRN2 Parallel Logic. Identical to HGRN (Element-wise Recurrence)."""
    b, h, l, d = x.shape
    pad_len = (chunk_size - l % chunk_size) % chunk_size
    if pad_len > 0:
        g, x = [F.pad(t, (0, 0, 0, pad_len)) for t in [g, x]]
        
    g = rearrange(g, 'b h (n c) d -> b h n c d', c=chunk_size)
    x = rearrange(x, 'b h (n c) d -> b h n c d', c=chunk_size)
    
    if initial_state is not None:
        S = initial_state
    else:
        S = torch.zeros(b, h, d, device=x.device)
        
    o_list = []
    block_size = 32
    
    for i in range(g.shape[2]):
        g_chunk = g[:, :, i]
        x_chunk = x[:, :, i]
        o_chunk_slices = []
        S_new_slices = []
        
        for start_idx in range(0, d, block_size):
            end_idx = min(start_idx + block_size, d)
            g_i = g_chunk[..., start_idx:end_idx]
            x_i = x_chunk[..., start_idx:end_idx]
            S_i = S[..., start_idx:end_idx]
            
            g_cumsum = torch.cumsum(g_i, dim=-2)
            decay_matrix = g_cumsum.unsqueeze(-2) - g_cumsum.unsqueeze(-3)
            mask = torch.triu(torch.ones(chunk_size, chunk_size, dtype=torch.bool, device=x.device), diagonal=1)
            decay_matrix = decay_matrix.masked_fill(mask.unsqueeze(-1), -float('inf'))
            decay_mask = torch.exp(decay_matrix)
            
            o_intra = torch.einsum('b h i j d, b h j d -> b h i d', decay_mask, x_i)
            
            decay_from_start = torch.exp(g_cumsum)
            o_inter = S_i.unsqueeze(2) * decay_from_start
            o_chunk_slices.append(o_intra + o_inter)
            
            total_decay = torch.exp(g_i.sum(dim=-2))
            decay_to_end = torch.exp(g_cumsum[:, :, -1].unsqueeze(-2) - g_cumsum)
            current_chunk_contrib = (x_i * decay_to_end).sum(dim=-2)
            S_new_slices.append(S_i * total_decay + current_chunk_contrib)
            
        S = torch.cat(S_new_slices, dim=-1)
        o_chunk = torch.cat(o_chunk_slices, dim=-1)
        o_list.append(o_chunk)
        
    o = torch.stack(o_list, dim=2)
    o = rearrange(o, 'b h n c d -> b h (n c) d')
    if pad_len > 0: o = o[..., :l, :]
    return o, S

# ==================== HGRN2 Layer (from i00-hgrn2) ====================

class HGRN2(nn.Module):
    def __init__(self, d_model, num_heads=None, expand_ratio=1.0, use_short_conv=True, neuron_type='sdn', **kwargs):
        super().__init__()
        self.d_model = d_model
        if num_heads is None: num_heads = d_model // 64
        self.num_heads = num_heads
        self.hidden_dim = int(d_model * expand_ratio)
        self.use_short_conv = use_short_conv

        surrogate = piecewise_quadratic_surrogate()

        self.g_proj = SpikingLinear(nn.Linear(d_model, self.hidden_dim, bias=False), neuron_type, surrogate)
        self.i_proj = SpikingLinear(nn.Linear(d_model, self.hidden_dim, bias=False), neuron_type, surrogate)

        if use_short_conv:
            self.conv_g = ShortConvolution(self.hidden_dim, kernel_size=4, activation=None)
            self.conv_i = ShortConvolution(self.hidden_dim, kernel_size=4, activation=None)

        self.o_proj = SpikingLinear(nn.Linear(self.hidden_dim, d_model, bias=False), neuron_type, surrogate)
        self.norm = RMSNorm(self.hidden_dim)

    def forward(self, x, past_key_values=None, layer_idx=None, **kwargs):
        all_spikes = {}
        g, s_g = self.g_proj(x)
        i, s_i = self.i_proj(x)
        all_spikes.update({'g': s_g, 'i': s_i})

        conv_state_g, conv_state_i = None, None
        if past_key_values is not None and layer_idx is not None:
             if len(past_key_values) > layer_idx:
                 states = past_key_values[layer_idx]
                 conv_state_g = states.get('conv_state_g')
                 conv_state_i = states.get('conv_state_i')

        if self.use_short_conv:
            g, conv_state_g = self.conv_g(g, cache=conv_state_g, output_final_state=True)
            i, conv_state_i = self.conv_i(i, cache=conv_state_i, output_final_state=True)

        g = rearrange(g, 'b l (h d) -> b h l d', h=self.num_heads)
        i = rearrange(i, 'b l (h d) -> b h l d', h=self.num_heads)

        # Use logsigmoid for stable parallel recurrence
        g = F.logsigmoid(g)
        i = F.silu(i)

        last_state = None
        if past_key_values is not None and layer_idx is not None:
            if len(past_key_values) > layer_idx:
                last_state = past_key_values[layer_idx].get('recurrent_state')

        o, final_state = hgrn2_chunkwise(g, i, initial_state=last_state)

        if past_key_values is not None and layer_idx is not None:
            new_cache = {
                'recurrent_state': final_state,
                'conv_state_g': conv_state_g,
                'conv_state_i': conv_state_i
            }
            if len(past_key_values) <= layer_idx:
                past_key_values.append(new_cache)
            else:
                past_key_values[layer_idx] = new_cache

        o = rearrange(o, 'b h l d -> b l (h d)')
        o = self.norm(o)
        o, s_o = self.o_proj(o)
        all_spikes['o'] = s_o
        return o, None, all_spikes

# ==================== SpikingMLP (from r01v2-988c59) ====================

class SpikingMLP(nn.Module):
    def __init__(self, d_model, d_ffn, dropout=0.1, neuron_type='sdn', surrogate_function=None):
        super().__init__()
        self.fc1 = SpikingLinear(nn.Linear(d_model, d_ffn), neuron_type, surrogate_function)
        self.dropout = nn.Dropout(dropout)
        self.fc2 = SpikingLinear(nn.Linear(d_ffn, d_model), neuron_type, surrogate_function)

    def forward(self, x):
        x, spike1 = self.fc1(x)
        x = F.gelu(x)
        x, spike2 = self.fc2(self.dropout(x))
        return x, spike1, spike2

# ==================== Centered SpikingResidualGate ====================

class CenteredSpikingResidualGate(nn.Module):
    def __init__(self, d_model: int, neuron_type: str, surrogate_function):
        super().__init__()
        self.proj_in = SpikingLinear(nn.Linear(1, d_model // 2, bias=False), neuron_type, surrogate_function)
        self.proj_out = SpikingLinear(nn.Linear(d_model // 2, 1, bias=False), neuron_type, surrogate_function)
        self.bias = nn.Parameter(torch.zeros(1))

    def forward(self, avg_activity: torch.Tensor) -> Tuple[torch.Tensor, List[torch.Tensor]]:
        spikes_list = []

        x_cont, spikes1 = self.proj_in(avg_activity)
        spikes_list.append(spikes1)

        x_act = F.gelu(x_cont)

        mod_factor_raw, spikes2 = self.proj_out(x_act)
        spikes_list.append(spikes2)

        # Centered modulation factor: range [0, 2], centered at 1.0
        modulation_factor = 2.0 * torch.sigmoid(mod_factor_raw + self.bias)

        return modulation_factor, spikes_list

# ==================== SpikingFLABlock ====================

class SpikingFLABlock(nn.Module):
    def __init__(self, d_model, num_heads, d_ffn_mult=2, dropout=0.1, prenorm=True, neuron_type='sdn', **kwargs):
        super().__init__()
        self.prenorm = prenorm
        self.norm1 = RMSNorm(d_model)
        self.attn = HGRN2(d_model=d_model, num_heads=num_heads, neuron_type=neuron_type, **kwargs)
        self.dropout1 = nn.Dropout(dropout)

        self.attn_residual_gate = CenteredSpikingResidualGate(d_model, neuron_type, piecewise_quadratic_surrogate())

        self.norm2 = RMSNorm(d_model)
        d_ffn = d_model * d_ffn_mult

        self.mlp = SpikingMLP(d_model=d_model, d_ffn=d_ffn, dropout=dropout, neuron_type=neuron_type, surrogate_function=piecewise_quadratic_surrogate())

        self.dropout2 = nn.Dropout(dropout)
        self.mlp_residual_gate = CenteredSpikingResidualGate(d_model, neuron_type, piecewise_quadratic_surrogate())

    def forward(self, x: torch.Tensor, **kwargs) -> Tuple[torch.Tensor, Optional[torch.Tensor], Optional[torch.Tensor]]:
        all_spikes_list = []

        # Attention Block (HGRN2)
        x_res = x
        if self.prenorm: x = self.norm1(x)

        x_attn, _, attn_spikes_dict = self.attn(x, **kwargs)

        attn_block_mean_spike_activities = []
        if attn_spikes_dict:
            for spike_tensor_name, spike_tensor in attn_spikes_dict.items():
                if spike_tensor is not None:
                    all_spikes_list.append(spike_tensor)
                    attn_block_mean_spike_activities.append(spike_tensor.float().mean(dim=-1, keepdim=True))

        if attn_block_mean_spike_activities:
            avg_attn_mean_activity = torch.mean(torch.stack(attn_block_mean_spike_activities), dim=0)
            attn_modulation_factor, attn_gate_spikes = self.attn_residual_gate(avg_attn_mean_activity)
            all_spikes_list.extend(attn_gate_spikes)
            x_attn = x_attn * attn_modulation_factor

        x = x_res + self.dropout1(x_attn)

        # MLP Block
        x_res = x
        if self.prenorm: x = self.norm2(x)

        x_mlp, mlp_spike1, mlp_spike2 = self.mlp(x)

        mlp_block_mean_spike_activities = []
        if mlp_spike1 is not None:
            all_spikes_list.append(mlp_spike1)
            mlp_block_mean_spike_activities.append(mlp_spike1.float().mean(dim=-1, keepdim=True))
        if mlp_spike2 is not None:
            all_spikes_list.append(mlp_spike2)
            mlp_block_mean_spike_activities.append(mlp_spike2.float().mean(dim=-1, keepdim=True))

        if mlp_block_mean_spike_activities:
            avg_mlp_mean_activity = torch.mean(torch.stack(mlp_block_mean_spike_activities), dim=0)
            mlp_modulation_factor, mlp_gate_spikes = self.mlp_residual_gate(avg_mlp_mean_activity)
            all_spikes_list.extend(mlp_gate_spikes)
            x_mlp = x_mlp * mlp_modulation_factor

        x = x_res + self.dropout2(x_mlp)

        final_spikes = torch.cat([s.flatten() for s in all_spikes_list]) if all_spikes_list else torch.empty(0, device=x.device, dtype=torch.bool)

        return x, None, final_spikes