#!/usr/bin/env python3
"""Replay one real generation of the OpenArchEvo v2 loop inside this sandbox ("agents propose, evolution decides").

Data: references/generation6.json = generation 6 of run V2_s5 (a pre-registered replication run, 10-24): the research
lead's real analysis and directions, the 9 real proposals (code), their parents, and what happened next.

  python scripts/generation.py brief                    # 1. what the research-lead agent saw and wrote (agents propose)
  python scripts/generation.py replay                   # 2. re-run the deterministic gates on the 9 real proposals
  python scripts/generation.py select                   # 3. NSGA-II selection on the survivors (evolution decides)
  python scripts/generation.py check child.py --slot N  # live: gate YOUR OWN proposal for slot N the same way
  python scripts/generation.py parent ID --out p.py     # write a parent's code (for the live mode)

Writes generation_report.md (appends one section per command). Gates need torch + einops (CPU); without them `replay`
falls back to the verdicts recorded in the real run and says so.
"""
import argparse
import json
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
G = json.loads((HERE.parent / "references" / "generation6.json").read_text())
WD = Path.cwd() / "gen6"
REPORT = Path.cwd() / "generation_report.md"


def out(lines):
    txt = "\n".join(lines) + "\n"
    print(txt)
    with REPORT.open("a") as f:
        f.write(txt + "\n")
    print(f"[done] section appended to {REPORT}")


def have_torch():
    try:
        import torch  # noqa: F401
        import einops  # noqa: F401
        return True
    except Exception:
        return False


def write_files():
    WD.mkdir(exist_ok=True)
    for k, p in G["parents"].items():
        (WD / f"{k}.py").write_text(p["code"])
    for p in G["proposals"]:
        (WD / f"{p['id']}.py").write_text(p["code"])


def gate(child, base):
    """Spiking-contract / interface check, then functional equivalence against the base parent."""
    c = subprocess.run([sys.executable, str(HERE / "cpu_check.py"), str(child), "--json", str(child) + ".check.json"],
                       capture_output=True, text=True, timeout=900)
    try:
        ck = json.loads(Path(str(child) + ".check.json").read_text())
    except Exception:
        ck = {"passed": False, "stage": "crash", "error": c.stderr[-300:]}
    if not ck.get("passed"):
        return "BLOCKED: contract/interface", f"stage {ck.get('stage')}: {str(ck.get('error'))[:120]}"
    subprocess.run([sys.executable, str(HERE / "func_equiv.py"), str(WD / f"{base}.py"), str(child), "--json", str(child) + ".fe.json"],
                   capture_output=True, text=True, timeout=900)
    try:
        fe = json.loads(Path(str(child) + ".fe.json").read_text())
    except Exception:
        return "PASS (equivalence test failed to run)", ""
    if fe.get("equivalent"):
        return "BLOCKED: functionally equivalent to parent", "same outputs with the parent's weights copied in: a changed-but-identical edit"
    return "PASS", f"params/block {ck.get('params_per_block', ck.get('params'))}, fire rate {round(ck.get('fire_rate') or 0, 3)}"


def cmd_brief(a):
    L = [f"## 1. Agents propose — research lead, generation {G['generation']} of run {G['run']}", "",
         "The research-lead agent (on SciencePal) read a deterministic results table and checked archive knowledge, then wrote",
         "one research direction per slot. **Parents and roles were chosen by the evolutionary rules, not by the agent**",
         "(when agents chose parents themselves, population diversity fell from 0.97 to 0.61 in our study E3).", "",
         "### The lead's analysis (verbatim, truncated)", "", G["lead_analysis"][:1500].strip(), "",
         "### Slots: rule-chosen role/parents + MOEA/D weight [quality, size] + the agent's direction", "",
         "| slot | proposal | role | parents | weight | direction (agent) |", "|---|---|---|---|---|---|"]
    for i, p in enumerate(G["proposals"], 1):
        L.append(f"| {i} | {p['id']} | {p['role']} | {', '.join(p['parents'])} | {p['weight']} | {(p['direction'] or '')[:220]} |")
    L += ["", "A DeepSeek proposer with Skill v0.3.3 then wrote one program per slot (bundled; see `replay`)."]
    out(L)


def cmd_replay(a):
    write_files()
    t = a.live and have_torch()
    pre = G.get("precomputed_gate_verdicts", {})
    L = ["## 2. Deterministic gates on the 9 real proposals", "",
         "Each proposal must (i) pass the spiking-contract and interface check, and (ii) actually change the computation "
         "of its base parent (functional-equivalence test: copy the parent's weights in, compare outputs).", ""]
    if not t:
        L += [f"**FAST MODE — verdicts below were precomputed, not re-run in this sandbox.** "
              f"**Fast mode: gate verdicts precomputed with the bundled scripts ({pre.get('note', '')}).** "
              "To recompute them yourself here: install torch + einops (§3 step 1; 5-25 min in a fresh sandbox), then "
              "`python scripts/generation.py replay --live` (~1 min).", ""]
    L += ["| proposal | role | base parent | " + ("gate verdict, re-run here" if t else "gate verdict (bundled scripts, precomputed)") + " | real run (GPU fingerprint gate) |", "|---|---|---|---|---|"]
    for p in G["proposals"]:
        if t:
            v, why = gate(WD / f"{p['id']}.py", p["parents"][0])
        else:
            v, why = pre.get("verdicts", {}).get(p["id"], "(not available)"), ""
        real = {"registered": "passed", "parent_fingerprint_match": "BLOCKED: behaves like parent",
                "near_duplicate": "BLOCKED: near-duplicate"}.get(p["real_gate"], p["real_gate"])
        L.append(f"| {p['id']} | {p['role']} | {p['parents'][0]} | {v} {('— ' + why) if why else ''} | {real} |")
    L += ["", "In the real run, 2 of 9 proposals were stopped before any GPU training because they behaved like their parent. "
          "One of them is provably equivalent (dead change); without the gates it would have cost a training."]
    out(L)


def nsga2_rank(objs):
    n = len(objs)
    dom = lambda a, b: all(x <= y for x, y in zip(a, b)) and any(x < y for x, y in zip(a, b))
    rank, front, r = [None] * n, [i for i in range(n) if not any(dom(objs[j], objs[i]) for j in range(n))], 0
    left = set(range(n))
    while left:
        front = [i for i in left if not any(dom(objs[j], objs[i]) for j in left if j != i)]
        for i in front:
            rank[i] = r
        left -= set(front)
        r += 1
    return rank


def cmd_select(a):
    S = [p for p in G["proposals"] if p["real_gate"] == "registered"]
    objs = [(p["predicted_ppl"], max(v[0] for v in p["parent_similarity"].values())) for p in S]
    rk = nsga2_rank(objs)
    L = ["## 3. Evolution decides — NSGA-II on the survivors", "",
         "Objectives (both minimised): predicted PPL from the controller's surrogate (behaviour fingerprint -> fitness), and "
         "code similarity to the closest parent (lower = more novel). The agent does not choose what gets trained.", "",
         "| proposal | role | predicted PPL | similarity to parent | Pareto rank | trained in the real run | measured 2-epoch PPL |",
         "|---|---|---|---|---|---|---|"]
    for p, o, r in sorted(zip(S, objs, rk), key=lambda x: (x[2], x[1][0])):
        L.append(f"| {p['id']} | {p['role']} | {o[0]:.2f} | {o[1]:.3f} | {r} | {'yes' if p['selected_for_training'] else 'no'} | "
                 f"{'' if p['e2_ppl'] is None else round(p['e2_ppl'], 2)} |")
    later = G["later"]["r06v2-5fbf90"]
    L += ["", "Note: the real controller selects across the whole population each generation (2 trainings per generation), "
          "so a candidate can be trained a generation later; the Pareto ranks above use this generation's survivors only.", "",
          f"**What happened next:** r06v2-5fbf90 (a *simplify* child) reached {G['proposals'][6]['e2_ppl']:.2f} at 2 epochs — "
          f"the best of its run, below the best expert DeltaNet (120.64) — and {later['e6_ppl_seed0']} after 6 epochs vs "
          f"DeltaNet's 3-seed mean {later['deltanet_e6_mean_3seeds']} ({later['note']})."]
    out(L)


def cmd_check(a):
    write_files()
    slot = G["proposals"][a.slot - 1]
    if not have_torch():
        print("torch/einops required for the live check; see `replay` for the install command")
        return
    v, why = gate(Path(a.child).resolve(), slot["parents"][0])
    out([f"## Live check — your proposal for slot {a.slot} ({slot['role']}, base parent {slot['parents'][0]})", "",
         f"Verdict: **{v}** {why}", "",
         "In the full system a passing proposal would next get a GPU behaviour fingerprint and compete in NSGA-II selection; "
         "nothing is trained in this demo."])


def cmd_parent(a):
    code = G["parents"].get(a.id, {}).get("code")
    if not code:
        sys.exit(f"unknown parent {a.id}; known: {', '.join(G['parents'])}")
    Path(a.out).write_text(code)
    print("wrote", a.out)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    sp = ap.add_subparsers(dest="cmd", required=True)
    sp.add_parser("brief")
    r = sp.add_parser("replay")
    r.add_argument("--live", action="store_true", help="re-run the gates here (needs torch + einops)")
    sp.add_parser("select")
    c = sp.add_parser("check")
    c.add_argument("child")
    c.add_argument("--slot", type=int, required=True)
    p = sp.add_parser("parent")
    p.add_argument("id")
    p.add_argument("--out", required=True)
    a = ap.parse_args()
    {"brief": cmd_brief, "replay": cmd_replay, "select": cmd_select, "check": cmd_check, "parent": cmd_parent}[a.cmd](a)
