#!/usr/bin/env python3
"""Browse the OpenArchEvo parent library bundled with this Skill.

The index (references/library_index.jsonl, ~65 KB) holds one line per program; code and full design rationale
live in scripts/library_code.zip and are extracted one program at a time. Never read the zip or the whole
index into your context; use these commands.

  python scripts/library.py list [--family DeltaNet] [--top 20]   # key, name, family, historical WT2 PPL
  python scripts/library.py show KEY [--out parent_KEY.py]        # print rationale; write code to a file
  python scripts/library.py demo                                   # recommended demo parents
  python scripts/library.py case r02a-4fdb1d                       # a program from references/case_studies.md
Historical metrics are background from an earlier study (different protocol); never report them as results.
"""
import argparse
import json
import sys
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
IDX = HERE.parent / "references" / "library_index.jsonl"
ZIP = HERE / "library_code.zip"


def load():
    lines = IDX.read_text(encoding="utf-8").splitlines()
    return json.loads(lines[0]), [json.loads(l) for l in lines[1:] if l.strip()]


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("list"); p.add_argument("--family"); p.add_argument("--top", type=int, default=200)
    p = sub.add_parser("show"); p.add_argument("key"); p.add_argument("--out")
    sub.add_parser("demo")
    p = sub.add_parser("case"); p.add_argument("key", help="r01b-c8c630 | r02a-4fdb1d | r01a-66286b | r01a-b7e4ea | r01b-4d71a8 | r04b-0c5e28"); p.add_argument("--out")
    a = ap.parse_args()
    if a.cmd == "case":  # programs from the hackathon case studies (references/case_studies.md)
        with zipfile.ZipFile(ZIP) as z:
            code = z.read(f"case_{a.key}.py").decode()
            note = z.read(f"case_{a.key}.md").decode()
        out = Path(a.out or f"case_{a.key}.py")
        out.write_text(code, encoding="utf-8")
        if not out.exists() or out.stat().st_size == 0:
            sys.exit(f"could not write {out}")
        print(f"WROTE {out} ({out.stat().st_size} bytes) for case {a.key}\n{note[:1500]}")
        return
    head, progs = load()
    by = {p["key"]: p for p in progs}
    if a.cmd == "demo":
        print(json.dumps(head, indent=1))
        print("\nNext (SKILL.md §6): A) pick a parent above and run one audited generation; "
              "B) replay the audits (case r02a-4fdb1d, r01a-66286b vs r01a-b7e4ea, r01b-c8c630 vs i00-hgrn2); "
              "C) summarise references/case_studies.md.")
        return
    if a.cmd == "list":
        rows = [p for p in progs if not a.family or p["base_family"] == a.family]
        rows.sort(key=lambda p: p["hist_wt2_ppl"] or 1e9)
        print(head["_note"])
        for p in rows[: a.top]:
            print(f'{p["key"]:12s} {p["base_family"]:22s} hist_wt2_ppl={p["hist_wt2_ppl"]}  {p["name"]}')
        return
    p = by.get(a.key)
    if not p:
        sys.exit(f"unknown key {a.key}")
    with zipfile.ZipFile(ZIP) as z:
        code = z.read(f"{a.key}.py").decode()
        rat = z.read(f"{a.key}.md").decode() if f"{a.key}.md" in z.namelist() else ""
    out = Path(a.out or f"parent_{a.key}.py")
    out.write_text(code, encoding="utf-8")
    print(f"# {p['key']} | {p['name']} | family {p['base_family']} | hist_wt2_ppl {p['hist_wt2_ppl']} (historical)")
    print(f"# cpu-demo-v1: {p['cpu_demo_v1']}\n# code written to {out}\n")
    print(rat or "(no rationale)")


if __name__ == "__main__":
    main()
