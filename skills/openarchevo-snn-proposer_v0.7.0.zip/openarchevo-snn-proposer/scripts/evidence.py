#!/usr/bin/env python3
"""Recompute the main OpenArchEvo v1-vs-v2 evidence from the raw per-run outcomes bundled with this Skill.

  python scripts/evidence.py                 # budget 15 trainings per run, writes evidence.md (+ evidence.png if matplotlib)
  python scripts/evidence.py --budget 17
  python scripts/evidence.py --run V2_s1     # list every trained child of one run, in budget order

Pure Python (no numpy/scipy/torch needed). The one-sided Mann-Whitney p-value is computed exactly by enumerating
all splits of the pooled per-run values (5 + 5 runs -> 252 splits), with mid-ranks for ties.
"""
import argparse
import itertools
import json
import statistics
from pathlib import Path

HERE = Path(__file__).resolve().parent.parent
D = json.loads((HERE / "references" / "evidence.json").read_text())


def per_run(rows, budget):
    rows = rows[:budget]
    ok = [r["ppl"] for r in rows if r["kind"] == "ok"]
    return {"n": len(rows), "good": sum(1 for v in ok if v < D["good_threshold"]),
            "bad": sum(1 for r in rows if r["kind"] != "ok"),
            "median": round(statistics.median(ok), 2) if ok else None,
            "best": round(min([D["best_expert"]["ppl"]] + ok), 2)}


def ranks(vals):
    s = sorted(vals)
    return [ (2 * s.index(v) + s.count(v) + 1) / 2 for v in vals]


def mw_p(x, y, alternative):
    """Exact one-sided p of Mann-Whitney: P(rank-sum of x >= observed) for 'greater', <= for 'less'."""
    pool = x + y
    r = ranks(pool)
    obs = sum(r[:len(x)])
    tot = cnt = 0
    for idx in itertools.combinations(range(len(pool)), len(x)):
        s = sum(r[i] for i in idx)
        tot += 1
        if (alternative == "greater" and s >= obs - 1e-9) or (alternative == "less" and s <= obs + 1e-9):
            cnt += 1
    return cnt / tot


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--budget", type=int, default=15)
    ap.add_argument("--run")
    a = ap.parse_args()
    if a.run:
        for i, r in enumerate(D["runs"][a.run], 1):
            print(f"{i:2d} {r['id']:16s} {r['role'] or '':10s} {r['kind']:9s} ppl={r['ppl']}  delta_vs_parent={r['delta_vs_parent']}")
        return
    R = {k: per_run(v, a.budget) for k, v in D["runs"].items() if len(v) >= a.budget}
    arms = sorted({k.split("_")[0] for k in R})
    L = [f"# Evidence recomputed from raw outcomes (budget {a.budget} trainings per run)", "",
         f"Protocol: {D['protocol']}. Good = PPL < {D['good_threshold']} (within 2 PPL of the best expert, DeltaNet "
         f"{D['best_expert']['ppl']}); bad = failed, diverged or PPL > {D['bad_threshold']}.", "",
         "| run | good | bad (wasted) | median child PPL | best PPL so far |", "|---|---|---|---|---|"]
    for k in sorted(R):
        r = R[k]
        L.append(f"| {k} | {r['good']} | {r['bad']} | {r['median']} | {r['best']} |")
    L += ["", "| arm | runs | mean good | mean bad | wasted share of trainings | best PPL |", "|---|---|---|---|---|---|"]
    S = {}
    for arm in arms:
        rs = [R[k] for k in R if k.startswith(arm + "_")]
        S[arm] = rs
        L.append(f"| {arm} ({D['arms'].get(arm, '')}) | {len(rs)} | {statistics.mean(r['good'] for r in rs):.1f} | "
                 f"{statistics.mean(r['bad'] for r in rs):.1f} | {sum(r['bad'] for r in rs) / (a.budget * len(rs)):.0%} | "
                 f"{min(r['best'] for r in rs)} |")
    if "V1" in S and "V2" in S:
        g1, g2 = [r["good"] for r in S["V1"]], [r["good"] for r in S["V2"]]
        b1, b2 = [r["bad"] for r in S["V1"]], [r["bad"] for r in S["V2"]]
        L += ["", "Exact one-sided Mann-Whitney tests, V2 vs V1 (unit = one independent run):",
              f"- wasted trainings, V2 < V1: p = {mw_p(b2, b1, 'less'):.3f}  (V1 {b1}, V2 {b2})",
              f"- good children, V2 > V1: p = {mw_p(g2, g1, 'greater'):.3f}  (V1 {g1}, V2 {g2})",
              "", "Honest notes: the best PPL found is about the same in both arms (the pre-registered 'v2 finds a lower best' "
              "prediction failed); 'good' and 'bad' counts were defined after the first night and then tested in a "
              "pre-registered replication (E9). Scale is small (2-epoch WikiText-2 proxy)."]
    (Path.cwd() / "evidence.md").write_text("\n".join(L) + "\n")
    print("\n".join(L))
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        fig, axs = plt.subplots(1, 2, figsize=(8, 3.2), dpi=130)
        col = {"V1": "#9a9a9a", "A": "#c49a3c", "V2": "#2a6f97"}
        for ax, key, t in zip(axs, ("bad", "good"), ("wasted trainings per run", "good children per run")):
            for i, arm in enumerate(arms):
                v = [r[key] for r in S[arm]]
                ax.scatter([i] * len(v), v, color=col.get(arm, "k"), alpha=.7)
                ax.hlines(statistics.mean(v), i - .25, i + .25, color=col.get(arm, "k"), lw=3)
            ax.set_xticks(range(len(arms)), arms)
            ax.set_title(t + f" (budget {a.budget})", fontsize=9)
            ax.grid(alpha=.3)
        fig.tight_layout()
        fig.savefig("evidence.png")
        print("\nwrote evidence.md and evidence.png")
    except Exception:
        print("\nwrote evidence.md (matplotlib not installed: no figure)")


if __name__ == "__main__":
    main()
