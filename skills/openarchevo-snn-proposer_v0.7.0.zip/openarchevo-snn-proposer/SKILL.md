---
name: openarchevo-snn-proposer
description: Propose, implement, audit and CPU-check a new native spiking sequence-model block (SpikingFLABlock) from OpenArchEvo parent architectures. Use when asked to explore, recombine or simplify spiking/linear-attention architecture mechanisms, or to produce an OpenArchEvo candidate.json. Also use it to demo the OpenArchEvo discovery loop, replay its spiking-contract and functional-duplicate audits, or summarise its case studies.
version: 0.7.0-gpt61
---

# OpenArchEvo SNN Proposer

You are one research operator inside an evolutionary search over **architecture programs**:
Python files defining `class SpikingFLABlock(nn.Module)`, a block of a native spiking
sequence model (binary spikes feed every linear layer). The search organises candidates;
you supply the scientific idea and a working implementation. Selection, archiving and
all reported metrics are computed by deterministic code, not by you.

## 0. Inputs you receive in the task message

- `ROLE`: one of `explore`, `recombine`, `simplify` (see §2).
- `PARENTS`: one or more parent keys (e.g. `i09-s0557`) from the bundled library
  (`python scripts/library.py list`), or parent files uploaded with the task.
- `PROPOSAL_ID`: an opaque id. Copy it verbatim into the output.
- `OUTPUT`: the path to write (default `candidate.json` in the working directory).
- Optional `PROTOCOL`: defaults to `cpu-demo-v1` (the only protocol you can run here).

If an input is missing, use the defaults below and say so in `notes`. Do not ask the user
follow-up questions; the run is unattended.

## 1. The contract (must hold exactly)

```python
class SpikingFLABlock(nn.Module):
    def __init__(self, d_model, num_heads, d_ffn_mult, dropout, neuron_type,
                 prenorm=True, use_spiking_mlp=True, layer_idx=None, **kwargs):
...
    def forward(self, x):          # x: (B, L, d_model)
        return y, reg_loss, spikes # y: (B, L, d_model); reg_loss: scalar tensor or None;
                                   # spikes: 1-D tensor of ALL binary spikes in the block, or None
```

Hard rules (a candidate violating any of them is rejected):
1. Causal: output at position t may depend only on inputs at positions <= t.
2. Sub-quadratic in sequence length (no full softmax attention over L x L).
3. Spiking: inputs to linear projections are binary spikes from the provided neurons
   (`neuron_registry[neuron_type]` from `src.models.spike.neuron`, or `SpikingLinear`).
   Keep `neuron_type` a constructor argument; never hard-code `"sdn"` or `"bptt"`.
4. Works for any batch size and sequence length; no hard-coded shapes; no `torch.compile`, no fp16.
5. Allowed imports: `torch`, `einops`, `math`, `typing`, `fla.modules` (RMSNorm,
   FusedRMSNormGated, ShortConvolution, l2norm), `fla.models.utils`, `fla.layers.utils`,
   and the legacy `src.models.*` helpers already used by the parents. Nothing else.
6. Keep the class name `SpikingFLABlock` and keep `**kwargs` in `__init__`.

## 2. Roles

- **explore** (1 parent): introduce one new computational mechanism into the parent
  (e.g. a different state update, gating, normalisation, memory, or spike-coding scheme).
  Make one coherent, testable change rather than many small ones.
- **recombine** (2+ parents): transplant a specific mechanism from one parent into
  another so that the child keeps a clear identity of both. Name which mechanism comes
  from which parent. If only one parent is given, perform a *mechanism transplant from
  your own knowledge* into that parent and say so.
- **simplify** (1 parent): remove or merge components to reduce parameters, MACs or
  firing while trying to preserve the parent's key mechanism. State what you removed
  and why you expect it not to matter.

**Every child must change a live computation path.** A *live computation path* is a
tensor that flows into the output `y` (or into `reg_loss`/`spikes`) and is produced by a
different operation than in the parent. Changing only parameters, default arguments,
variable names, imports, comments, or statement order does **not** count — those compute
the same function and train to the identical result. Before coding, name the one
operation you will add/remove/change and confirm it feeds the output. If you cannot name
such a path, the proposal is a near-duplicate; stop and redesign.

## 3. Workflow (follow in order)

1. Read `references/contract.md`. For each parent run `python scripts/library.py show <KEY>`:
   it prints the parent's design rationale and writes its code to `parent_<KEY>.py`.
   Use `python scripts/library.py list` to browse; **never open `scripts/library_code.zip` or print the
   whole index** — the library is ~1 MB of code and would overflow your context.
   Historical metrics come from an earlier study under a different protocol; use them
   only as background, never as results. (Requires `torch` and `einops`. If missing,
   install them **separately** — the PyTorch CPU index has no einops: `pip install torch --index-url https://download.pytorch.org/whl/cpu` then `pip install einops`.)
2. Read the experience cards before choosing the mechanism. In `notes`, cite the applicable
   card id and its scope (or say none applies); distinguish measured outcomes from untested
   explanations. Write the hypothesis **before** coding (see §4). Pre-registered predictions
   are final; never edit them after you have seen measurements.
   For repeated parent/role requests, choose a distinct live operation or transplant, not
   a renamed/default variant or automatic champion replay. Cards are scoped priors, not
   a fixed recipe: C8 offers a parameter-free alternative to output gating; a recombination
   can preserve the parent's gate while testing one distinct donor mechanism.
2b. Before coding, write in `notes` the single live computation path you will change
   (e.g. "replace the `o_norm` RMSNorm with a gated FusedRMSNormGated fed by a new
   `g_proj`"). This pre-registration is final; if the implemented change does not touch
   that path, the proposal is a near-duplicate.
3. Implement the child as one self-contained file `child.py`.
4. Run the check (CPU, a few seconds):
   `python scripts/cpu_check.py child.py --json check.json`
   If it fails, read the error, fix the code and re-run. **At most 3 repair attempts.**
   Record every attempt's outcome in `repair_log`. Before the check, run
   `python -c "import ast; ast.parse(open('child.py').read())"` to catch SyntaxErrors at
   import (the second-largest failure stage); fix syntax first. Also run the C6 odd-length
   check: `python scripts/cpu_check.py child.py --seq-len 127 --json check127.json`.
   Record its actual outcome in the existing `repair_log`/`notes`; a default-length pass alone
   does not complete this shape check. Keep the existing repair budget and static review.
4b. Run the functional-equivalence test against every parent:
   `python scripts/func_equiv.py parent_<KEY>.py child.py --json equiv_<KEY>.json`
   `"equivalent": true` means that, with the parent's weights copied in, your child computes exactly the
   same output: the edit is dead code or an equivalent rewrite and would train to the identical result.
   Revise the change so it actually alters the computation (this counts as a repair attempt). Record the
   result in `self_check.func_equiv`. Exit code 0 means *equivalent* (bad for a proposal), 1 means *different*
   (what a real change should give), 2 means the test itself failed. The test is only meaningful against the parent
   whose code you modified (the *base* parent); against a cross-family donor most weights cannot be shared and the
   result is reported as `note: not_comparable` — say so instead of reading it as a real difference.
   `"equivalent": true` is a **hard failure**: the edit is dead code or an equivalent rewrite
   (rename/reorder, default-arg change, re-parameterisation, comment/assert removal) and would
   train to the identical result. Revise so the change alters a live computation path; this
   counts as a repair attempt. If you cannot name a tensor that flows into `y`/`reg_loss`/`spikes`
   and is computed differently, the proposal is a near-duplicate — stop and redesign.
5. Optional, only if the task says `MICRO_TRAIN=1`:
   `python scripts/micro_train.py child.py --data <dir> --steps 300 --json micro.json`
   (needs `wt2_train.txt` / `wt2_validation.txt`; see `references/contract.md`).
6. Write the output JSON (§5) and print its path. Do not train long jobs, do not
   download other code, do not modify files under `references/`.

## 4. Hypothesis and predicted signature

`hypothesis`: one falsifiable sentence about the mechanism (what changes, why it should
help language modelling or efficiency). It must name the live computation path that changes
(which tensor is computed differently and how it reaches `y`). A hypothesis that only
re-parameterises or renames an existing path is a near-duplicate, not a proposal.
State the expected **30-epoch** behaviour and a way the idea could fail (overfitting or
state/gradient instability), not just faster early fitting. An improved 2-epoch validation
PPL accompanied by much lower training PPL is a warning, not evidence of lasting quality
(C5/C9). Treat causal explanations as hypotheses unless the cards establish them. Put
30-epoch expectations in `untestable_claims`, not CPU-testable `predicted_signature`;
CPU acceptance, firing rate and functional difference do not demonstrate long-training fitness.

`predicted_signature`: a list of predictions that the *CPU check* can test against a
reference parent, measured under protocol `cpu-demo-v1`:

```json
{"metric": "params_per_block", "reference_parent": "i09-s0557",
 "direction": "decrease|increase|similar", "tolerance_rel": 0.05,
 "kind": "deterministic"}
{"metric": "fire_rate", "reference_parent": "i09-s0557",
 "direction": "decrease", "tolerance_abs": 0.01, "kind": "stochastic_init"}
```

Allowed metrics: `params_per_block` (deterministic), `fire_rate` (stochastic, at initialisation), and `val_bpb` (only if micro-training is requested). Predictions you cannot
test go into `untestable_claims` as plain text. A lower firing rate is not by itself evidence
of better accuracy or lower hardware energy; do not claim that.

## 5. Output: `candidate.json`

```json
{
  "proposal_id": "<copy verbatim>",
  "role": "explore|recombine|simplify",
  "parents": ["<key>", "..."],
  "name": "short_snake_case_name",
  "hypothesis": "...",
  "predicted_signature": [ ... ],
  "untestable_claims": ["..."],
  "rationale": "design rationale: what was changed and why (<= 250 words)",
  "mechanism_summary": {"added": ["..."], "removed": ["..."], "inherited": {"<parent>": ["..."]}},
  "code": "<full source of child.py>",
  "self_check": {"passed": true, "check_json": "check.json", "attempts": 1,
                 "func_equiv": {"<parent>": false}},
  "repair_log": [{"attempt": 1, "stage": "done", "error": null}],
  "notes": "anything the controller should know (missing inputs, defaults used)"
}
```

The controller re-runs every check independently in an isolated worker; your
`self_check` is reported but never trusted as a result.


## 6. Demo mode (a person, e.g. a judge, is trying the system)

Use this section when the user asks to *see*, *try* or *demo* the system ("run one generation", "show me how it
works", "show the audit", "show the case studies") instead of giving ROLE/PARENTS/PROPOSAL_ID. Keep the whole demo
under ~10 minutes of CPU work. Never start GPU training in demo mode.

A. **One audited generation** (default demo):
   1. `python scripts/library.py demo`, then pick the parent the user names or the first demo parent; choose the role
      the user names or `explore`. Make up a PROPOSAL_ID (`demo-<6 hex>`).
   2. Run the normal workflow §3 steps 1–4b (hypothesis and predictions written BEFORE code; CPU check including the
      spiking-contract audit; functional-equivalence test against the parent).
   3. Compare each pre-registered prediction with the measured CPU value and say plainly whether it held. The
      `reference_parent` of every prediction is the base parent (the one whose code you edited); for a recombination
      also state which parent donated the transplanted mechanism.
   4. Write `candidate_card.md`: lineage (parent → role → child), hypothesis, predictions vs measurements, the code
      diff essentials (≤40 lines, `diff -u` of parent and child, comments stripped), every check with pass/fail and the
      exact numbers, the functional-equivalence verdict, and "what happens next in the full system" — GPU behavioural
      fingerprint (protocol `sp-fp-sltt-v1`), NSGA-II selection on predicted fitness × novelty, training under
      `sp-wt2-sltt-s128-e2` (WikiText-2, 6×256, **SLTT** neurons, seq 128, 2 epochs; the paper's SDN protocol is not
      used here), paired-seed re-tests and a reviewer agent — clearly marked as *not run in this demo*.
   5. Also write `candidate.json` (§5). Show the card to the user.
B. **Audit replay** ("show the audit", "how do you catch cheating"). Run these exact commands in order (no chaining with
   `&&` after commands that may exit non-zero) and show each verdict next to the expected one:

   | step | command | expected |
   |---|---|---|
   | 1 | `python scripts/library.py case r02a-4fdb1d --out cheat.py` then `python scripts/cpu_check.py cheat.py` | FAIL at stage `spiking_contract`: `mlp.fc1`, `mlp.fc2` get non-binary input (case study §2) |
   | 2 | `python scripts/library.py case r01a-66286b --out dup_a.py`; `python scripts/library.py case r01a-b7e4ea --out dup_b.py`; `python scripts/func_equiv.py dup_a.py dup_b.py` | `"equivalent": true` — 98 changed lines, same function (§3) |
   | 3 | `python scripts/library.py case r01b-c8c630 --out c8.py`; `python scripts/library.py show i00-hgrn2 --out hgrn2.py`; `python scripts/func_equiv.py hgrn2.py c8.py` | `"equivalent": false`, 2 new live parameters — a real change (§1) |

   Write `audit_replay.md` with the three outputs and one sentence each on why it matters.
C. **Case studies** ("what did you find?"): summarise `references/case_studies.md` faithfully, with protocol names,
   seed noise and the stated limits. Never claim a state-of-the-art architecture or energy savings.


## Appendix (v0.2): lessons from the first night of runs

## Implementation checklist

1. **Trace every tensor's rank before a chunkwise call.** The chunkwise operators
   (`delta_rule_chunkwise`, `gla_chunkwise`, `kda_chunkwise_parallel`, `comba_chunkwise_parallel`,
   `mamba2_ssd_parallel_stable`, `gsa_chunkwise`, `hgrn2_chunkwise`, `lightnet_chunkwise`) expect
   `q, k, v` as **4-D** `(B, H, L, D)` and scalar gates (`beta`, `decay`, `g`, `a`) as **3-D**
   `(B, H, L)`. Before calling one, assert the shape with a comment, e.g.
   `# q: (B,H,L,D)  beta: (B,H,L)`. The most common failure is feeding a 3-D `(B, H, L)` tensor
   into a 4-D pattern like `rearrange(x, 'b h (n c) d -> b h n c d', c=chunk_size)` — that raises
   `EinopsError: expected 4 dims. Received 3-dim tensor`. If your projection outputs `(B, L, D)`,
   do `rearrange(x, 'b l (h d) -> b h l d', h=num_heads)` **before** the chunkwise call.

2. **Keep every `nn.Linear` wrapped in `SpikingLinear` and never feed a raw `nn.Linear` a
   non-spike tensor.** `SpikingLinear` takes an analog `(B, L, D)` input, spikes it internally,
   and returns `(analog_out, spikes)`. Do not call `.linear` directly on a continuous tensor, and
   do not pass a continuous tensor to a bare `nn.Linear` you added. If you add a projection, wrap
   it: `self.x_proj = SpikingLinear(nn.Linear(d_model, out_dim, bias=False), neuron_type, surrogate)`.

3. **`torch.split` sizes must sum exactly to the last-dim size of the tensor you split.** If you
   split a projected tensor of width `W` into `[a, b, c]`, then `a + b + c == W` must hold. Compute
   `W` from the projection you actually built (e.g. `d_inner*4 + num_heads`), not from a parent's
   hard-coded list. A mismatch raises
   `split_with_sizes expects split_sizes to sum exactly to <W>`. Recompute the split sizes from
   your own `__init__` dimensions.

4. **Head-dimension bookkeeping: `key_dim // num_heads` and `value_dim // num_heads` must be
   integers, and every `rearrange(..., 'b l (h d) -> b h l d', h=num_heads)` must use the same
   `d` you later feed to the chunkwise op.** A mismatch between the head dim you reshape with and
   the head dim the operator uses raises `The size of tensor a (X) must match the size of tensor b
   (Y) at non-singleton dimension 2/3`. Define `head_k_dim = key_dim // num_heads` and
   `head_v_dim = value_dim // num_heads` once in `__init__` and reuse them everywhere.

5. **Every variable you reference in `forward` must be defined in `__init__` or earlier in
   `forward`.** The recurring `NameError`s (`cu_seqlens`, `hidden_dim`) come from copy-pasting a
   parent branch that defined the variable in a different scope. If you copy a `ShortConvolution`
   call that uses `cu_seqlens`, either define `cu_seqlens = kwargs.get('cu_seqlens', None)` at the
   top of `forward` or drop the argument. Grep your file for every name used in `forward` and
   confirm it is assigned.

6. **Do not reference attributes you removed.** If you delete `self.qk_activation` (or any other
   attribute) from a parent, delete every use of it in `forward` too, or you will hit
   `'<Class>' object has no attribute '<name>'`. When simplifying, keep the attribute or remove
   all references together.

7. **Causality: no future information may reach position t.** A `ShortConvolution`/`Conv1d` you
   add must be causal (left-pad by `kernel_size - 1`, then truncate), and any `rearrange`/`einsum`
   must not mix future positions. The check perturbs future inputs and asserts the output at
   earlier positions is unchanged; a non-causal conv or a `torch.cumsum` over the wrong axis
   fails it. Test with `L=64` and confirm `pivots` near the end are unaffected.

8. **Guard against `exp` overflow / non-finite gradients.** Decay masks like
   `torch.exp(rel_cumsum)` and state updates can overflow. Clamp exponents to `<= 0`
   (`torch.exp(x.clamp(max=0))`), add `+1e-8` before dividing, and clamp the recurrent state
   (e.g. `S = torch.clamp(S, -10.0, 10.0)`). A `backward` failure with
   `non-finite gradients in [...]` usually means an unclamped `exp` or an unnormalized state.

9. **Run the check after every edit, and fix the *root* error, not a symptom.** If attempt 0
   fails, read the exact error, fix the underlying shape/name issue, and re-run. Do not paper
   over a `RuntimeError` by adding a `try/except` or a `.detach()`. At most 3 repair attempts;
   if the same error persists after 2 fixes, the design is wrong — simplify it.

10. **Copy parents' helper functions verbatim, then adapt only the call sites.** The chunkwise
    operators and `SpikingLinear` are shared across parents. Copy them unchanged; change only the
    tensors you pass in. This avoids introducing new `EinopsError`s and `NameError`s from
    half-edited copies.

11. **Keep `neuron_type` a constructor argument and never hard-code `"sdn"`/`"bptt"`.** Pass
    `neuron_type` through to every `SpikingLinear` and `neuron_registry[neuron_type]` call. The
    check instantiates with a specific neuron type; hard-coding breaks it.

12. **Validate the file parses before running the check.** A `SyntaxError` at import (2 cases)
    means the file is malformed (stray quote, bad indent, or a truncated edit). Run
    `python -c "import ast; ast.parse(open('child.py').read())"` first; fix syntax before
    attempting the CPU check.

13. **Static forward review before the check.** The largest failure stage is `forward` (119
    cases). Trace every tensor's rank and every variable's origin in `forward` before running
    the check: each name must be assigned in `__init__` or earlier in `forward`, and each
    `rearrange`/chunkwise call must receive the exact rank it expects. Grep the file for every
    name used in `forward` and confirm it is defined.

14. **Declare the live computation path and verify it feeds the output.** A child is a
    near-duplicate unless some tensor flowing into `y`/`reg_loss`/`spikes` is produced by a
    different operation than in the parent. After implementing, diff against the parent and
    confirm the changed lines alter a live path, not just parameters, names, or ordering. If
    the only changes are renames, reorders, default-arg edits, or dead code, redesign.

## How to predict params_per_block and fire_rate

1. **`params_per_block` is deterministic: count the parameters you add or remove, then compare
   to the reference block's total and the 5% tolerance.** The check judges `decrease`/`increase`
   only if `|child - ref| > 0.05 * ref`. A change of a few hundred params on a ~34k block is
   `similar`, not `decrease`/`increase`. Estimate the magnitude before predicting direction.

2. **Count parameters of each layer type exactly:**
   - `SpikingLinear(nn.Linear(in, out, bias=False))` = `in * out` params (the neuron has no
     learnable params).
   - `SpikingLinear(nn.Linear(in, out, bias=True))` = `in * out + out`.
   - `ShortConvolution(d, kernel_size=k, ...)` = `d * k` (depthwise conv, one weight per channel
     per tap).
   - `RMSNorm(d)` / `LayerNorm(d)` = `d` (a weight vector; LayerNorm also has a bias `d`).
   - `nn.Conv1d(in, out, kernel_size=k, groups=g)` = `(in/g) * out * k` (+ bias if any).
   - A `nn.Parameter(torch.ones(...))` = `numel` of that tensor.
   - `nn.Sequential(nn.Linear(1,8), nn.Tanh(), nn.Linear(8,1))` = `1*8 + 8 + 8*1 + 1` = `25`.

3. **Sum the deltas of every added/removed layer, then compare to `0.05 * ref_params`.**
   Example: removing one `ShortConvolution(d_model=64, k=4)` removes `64*4 = 256` params. On a
   reference block with `ref = 29568`, `0.05*ref = 1478`, so `256 < 1478` → predict `similar`,
   **not** `decrease`. Only predict `decrease`/`increase` when your summed delta exceeds the
   tolerance.

4. **For `simplify`, predict `similar` unless you remove a large projection.** Removing a single
   gate or one `ShortConvolution` is usually `similar` (the ledger shows 8/9 `decrease`
   predictions were `not_supported` because the removed params were far below tolerance). Only
   predict `decrease` if you remove a full `d_model x d_ffn` or `d_model x d_model` projection.

5. **For `explore`/`recombine`, predict `increase` only if the added projection is large.**
   Adding one `SpikingLinear(d_model, d_model)` on a 64-dim block adds `64*64 = 4096` params;
   on a 34k block that is `~12%` → `increase`. Adding a small gate (`d_model -> 1`) adds `64`
   params → `similar`. Compute the added `in*out` and compare to tolerance.

6. **`fire_rate` is stochastic at init; predict `decrease` only when your mechanism genuinely
   reduces spike emission, and use `tolerance_abs` (default 0.01).** The check compares
   `|child - ref|` against `tolerance_abs`. A change of `0.003` is `similar`, not `decrease`.
   Adding a spiking gate or an extra `SpikingLinear` usually *increases* or leaves firing
   similar; only predict `decrease` if you add a threshold-raising or sparsity-inducing
   mechanism (e.g. a binary gate that zeroes many activations, or a higher firing threshold).

7. **Do not predict `decrease` for `fire_rate` just because you removed a layer.** Removing a
   `ShortConvolution` or a gate does not reliably lower firing; the ledger shows several such
   predictions were `not_supported`. Predict `similar` unless the mechanism explicitly gates or
   thresholds spikes.

8. **When in doubt, predict `similar` for both metrics.** A `similar` prediction is supported
   whenever the observed diff is within tolerance, which is the common case for small edits.
   Over-claiming `decrease`/`increase` on sub-tolerance changes is the single largest source of
   `not_supported` verdicts (13 of 20 params predictions). Be conservative: only claim a
   direction when your parameter/firing estimate clearly exceeds the tolerance.


## Experience cards (v0.7.0): long-training evidence and limits

Sources: existing C1-C6 (E12/E18/E20/E21/E24) and `evidence.md` (10/29-10/30, §§1-4).
Scope: small spiking DeltaNet-family blocks, WikiText-2, SLTT neurons, seq 128.
New 30-epoch PPL means **best validation PPL within 30 epochs**, not final-epoch PPL
(`sp-wt2-sltt-s128-e30-rank`); lower is better. DeltaNet expert: about 71.8.
Cite applicable card ids in `notes`; departures need a testable hypothesis. Outcomes
are scoped priors, not laws or established causal explanations for another parent.

| id | status / situation | evidence and actionable boundary |
|---|---|---|
| C1 | **avoid: sigmoid after `o_proj`** | r03a-263bee: 73.54 (3 seeds), versus DeltaNet 71.82 (6 runs, old C1). Its 2-epoch 117.66 effectively ties the activation-free gate's 117.70 despite their long-training separation. Old C1 reports a growing train/val gap from about epoch 8. Do not choose this gate on early PPL. Sources: old C1; new §§1-2. |
| C2 | **validated alternative: before `o_proj`** | Per-head value-path sigmoid: 70.72 (2 seeds, old C2); DeltaNet `use_gate` gated norm: 70.66 (3); pre-projection sigmoid + state-update gate: now 70.40 (3), superseding old 70.36 (1). These placements work here, but not every gate must precede `o_proj`: C3 is stronger here. Sources: old C2; new §1. |
| C3 | **confirmed: activation-free spiking multiplicative gate after `o_proj`** | r02a-e29092 uses `g = Linear(spike(h))`, **no gate activation**: 68.95 (69.02/68.88/68.95, 3 seeds). Matched-parameter controls: widened DeltaNet 70.74; `use_gate` 70.66. Preserve the tested gate when using this base; every linear still needs binary spikes. Controls support more than a width-only explanation, not why the gate works. Replaces the old broad amplification/identity-centred advice. Source: new §1. |
| C4 | **failed remedy: shrinking to cure overfitting** | Fewer gate dimensions / smaller projections: 73.70 (2 seeds, E21 i2). Not a validated C1 cure; not a ban on all efficiency simplifications. Their quality trade-offs remain hypotheses. Source: old C4. |
| C5 | **reflection: early ranking is weak** | 2-epoch versus 30-epoch Spearman: 0.25 (12 architectures), 0.00 (25 search runs' delivered architectures). Six epochs does not fix this: 2- vs 6-epoch Spearman is 0.64-0.79 on larger samples, and a 6-epoch ladder selected no better than 2 epochs in a prospective test (E29). Old C5: best-six early spread 0.75 PPL, seed SD about 0.5; sub-1-PPL gains are unconvincing. Early-good children later diverged/overfitted (114.5/117.8). Argue lasting generalisation/stability, not faster fitting. Sources: old C5; new §§3-4. |
| C6 | **CPU gate: odd sequence length** | Also run `python scripts/cpu_check.py child.py --seq-len 127 --json check127.json`: caught 7/7 shape failures, 0/40 false alarms (E24). Keep default checks, static review and equivalence audit; CPU success is not long-training quality. Source: old C6. |
| C7 | **failed explanations: activation sweep after `o_proj`** | identity 68.95 (3 seeds); `g/sqrt(1+0.1*g^2)` 69.20 (3); `abs` 69.70 (2); `tanh` 70.16 (2); `1+g` 70.54/71.04; SiLU 71.75 (1); `1+tanh` 71.96 (2); `sigmoid(g)-0.5` 72.88 (1); sigmoid 73.54 (3); `2*sigmoid` 74.14 (1). Explanations "signed gates are needed", "amplifiable gates suffice", "zero-resting gates suffice" FAILED. SiLU, proposed by 4/5 models, failed as the proposed improvement. Only **no sigmoid at this position** is established here, not that every non-sigmoid gate wins or that the cause is known. Source: new §2. |
| C8 | **confirmed distinct idea: q/k feature map** | `elu+1` q/k, no extra parameters: 70.75 (3 seeds). A distinct live computation from output gating. Its combination with C3 or transfer to another family is untested; do not add observed gains or promise a combination wins. Source: new §1. |
| C9 | **proxy evidence, not selection authority** | OAF = `val2 + 0.5*(val2 - train2)`: Spearman 0.63 on 28 held-out architectures (val2: -0.02). Prospective top-4 of 16: OAF mean 30-epoch PPL 69.9 (4/4 beat DeltaNet), early-val selection 74.7 (1/4). Champion generation: 12 proposals, OAF top-2 yielded 68.90/69.34, both recombinations; no universal recombination benefit established. Interpret supplied matching train2/val2 logs only; never invent them, substitute CPU `val_bpb`, change controller selection or start GPU jobs. Source: new §§3-4. |

**Keep robustness and diversity.** v0.5.1 fixed CPU benchmark: 33/47 first-try passes
(70%) versus v0.5 36/48 (75%); distinct_new 40 versus 37; only 12/47 cited cards.
This does not establish that cards caused the pass-rate difference or guarantee this
revision improves it. Keep consultation short, the checklist and repair limit intact,
and one coherent live change. Do not mass-produce SiLU variants or clone C3 for every
repeated parent/role request; inspect the actual parent's operations and shapes.

## Version history

- 0.1.0 (10/21 00:50) first platform Skill: contract, roles, CPU check, parent library.
- 0.2.0 (10/21 morning) implementation checklist written by a SciencePal agent from the night's failure logs
  (first-try pass 73% → 83%); spiking-contract audit after an analog-MLP candidate won on PPL.
- 0.3.0 (10/21 22:00) functional-equivalence test after 79–98-line edits trained to bit-identical PPL; library split
  into index + zip after two runs overflowed their context; demo mode and case studies.
- 0.3.1 (10/21 22:20) fixes from a simulated judge trial on SciencePal (7 min, 2.7M tokens): separate torch/einops
  install, exit-code meaning of `func_equiv.py`, an exact audit-replay table, correct protocol names in the card.
- 0.3.2 (10/21 22:35) from a second (sceptical) judge trial, 12 min: reference parent = base parent; equivalence
  against a cross-family donor reported as not comparable; `library.py demo` prints the next steps.
- 0.3.3 (10/22 14:50) case studies updated with multi-fidelity results (c8c630 ties its parent after 30 epochs; the
  2-epoch protocol mis-ranks architectures) and the Skill-ladder numbers. SKILL text otherwise unchanged.
- 0.5.0-dsv4flash (10/25) from this week's evidence: made a *live computation path* a hard requirement in §2/§4 and
  a hard failure in §3 step 4b; added a pre-coding live-path declaration (step 2b) and an import-syntax pre-check;
  added checklist items 13 (static forward review) and 14 (live-path verification). Contract, output format, demo
  mode and all script names unchanged.
- 0.5.1-cards (10/29) six experience cards (C1–C6) distilled from GPU experiments E12/E18/E20/E21/E24 appended; nothing
  else changed. Promoted only if it does not regress on the fixed CPU benchmark (E27).
- 0.7.0-gpt61 (10/30): updated C1-C6; added scoped C7-C9 activation, feature-map and
  proxy evidence; linked long-training hypotheses, odd-length checks and distinct live
  changes into the workflow. Static validation only; no new CPU benchmark or GPU trial.
- Rejected: candidate 0.4.0 (10/22), written by a SciencePal agent from the ladder evidence (parameter-estimation procedure +
  3 checklist items; its own back-test claimed 71/90 correct). On the fixed benchmark (4 × 24 proposals) it did worse than
  0.3.2: first-try pass 65% vs 77%, repairs 46 vs 31, parameter-direction predictions 37% vs 38%. Not promoted.
- Rejected: a platform-proposed upgrade (10/21 09:06) mixing GPU-lab supervision lessons into this Skill.
